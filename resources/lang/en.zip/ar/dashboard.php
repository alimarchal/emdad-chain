<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Dashboard Arabic Language Words
    |--------------------------------------------------------------------------
    |
    */

    'Dashboard' => 'لوحة القيادة',
    'Total RFQs' => 'Total RFQs',
    'Total Quotation(s)' => 'Total Quotation(s)',
    'Total Purchase Order(s)' => 'Total Purchase Order(s)',
    'Total Shipments Delivered' => 'Total Shipments Delivered',
    'Total User' => 'Total User',
    'Total Business' => 'Total Business',
    'Received RFQ' => 'Received RFQ',
];
