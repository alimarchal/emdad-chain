<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>{{config('app.name')}}</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="57x57" href="ficon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="ficon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="ficon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="ficon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="ficon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="ficon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="ficon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="ficon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="ficon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="ficon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="ficon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="ficon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="ficon/favicon-16x16.png">
    <link rel="manifest" href="ficon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="ficon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="Presento/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="Presento/assets/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link href="Presento/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="Presento/assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="Presento/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="Presento/assets/vendor/venobox/venobox.css" rel="stylesheet">
    <link href="Presento/assets/vendor/aos/aos.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="Presento/assets/css/style.css" rel="stylesheet">

    <style>
        .goog-logo-link {
            display: none !important;
        }

        .goog-te-gadget {
            line-height: 1px !important;
            color: transparent;
        }

        .goog-te-gadget .goog-te-combo {
            color: black !important;
        }

        div.goog-te-gadget {
            color: transparent !important;
        }

    </style>
</head>

<body>

<!-- ======= Header ======= -->
@include('webLayout.header')
<!-- End Header -->


<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">

    @if(Session::has('message'))
        <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
    @endif
    <div class="container" data-aos="zoom-in" data-aos-delay="100">
        <div class="row">
            <div class="col-xl-12">
                <h5 class="text-warning">Emdad Supply Chain Platform is facilitating Saudi Arabian local trade transition to a smarter and more sustainable industry under the vision.</h5>
                <h5 class="text-warning"> Thank you for visiting us. You may choose us to share with you the power of our platform and our expertise in supply chain management.
                </h5>
            </div>
            <div class="col-xl-6 d-none d-lg-block">
                <p class="text-white font-bold">As a Buyer you may achieve your Strategic Procurement Business Initiatives in a smarter way, such as:<br>
                </p>
                <ol class="text-white">
                    <li>Cost leadership</li>
                    <li>Value delivery</li>
                    <li>Operational efficiency</li>
                    <li>Innovation in services</li>
                    <li>Responsible sourcing</li>
                    <li>Skill development</li>
                </ol>
                {{--                <a href="#about" class="btn-get-started scrollto">Get Started</a>--}}
            </div>
            <div class="col-xl-6 d-none d-lg-block">
                <p class="text-white font-bold">And as a Supplier you may achieve your Strategic Sales Business Initiatives in a smarter way, such as
                </p>
                <ol class="text-white">
                    <li>Building strong relationships with your customers</li>
                    <li>Transparent communication</li>
                    <li>Customer optimization</li>
                    <li>Ensure products are delivered on time</li>
                    <li>Long-term relationship and business development</li>
                </ol>
                {{--                <a href="#about" class="btn-get-started scrollto">Get Started</a>--}}
            </div>
        </div>
    </div>

</section><!-- End Hero -->

<main id="main">


    <!-- ======= About Section ======= -->
    <section id="about" class="about section-bg">
        <div class="container" data-aos="fade-up">

            <div class="row no-gutters">
                <div class="content col-xl-5 d-flex align-items-stretch">
                    <div class="content">
                        <h3>Emdad Platform</h3>
                        <p>
                            It is one of the largest electronic platform incorporating high level of experiences and cutting technologies to serve the seller and the buyer in buying, selling, supply
                            and storage operations, at the lowest costs while providing the best logistic standards.
                        </p>
                        <a href="{{route('aboutUs')}}" class="about-btn"><span>About us</span> <i class="bx bx-chevron-right"></i></a>
                    </div>
                </div>
                <div class="col-xl-7 d-flex align-items-stretch">
                    <div class="icon-boxes d-flex flex-column justify-content-center">
                        <div class="row">
                            <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
                                <i class="bx bx-receipt"></i>
                                <h4>Vision</h4>
                                <p>To be the largest supply chain platform that has the largest number of suppliers and the largest logistical fleet in high quality standards.
                                </p>
                            </div>
                            <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                                <i class="bx bx-cube-alt"></i>
                                <h4>Goal</h4>
                                <p>Goal Emdad to be a trustable name as a supply chain platform.</p>
                            </div>
                        </div>
                    </div><!-- End .content-->
                </div>
            </div>

        </div>
    </section><!-- End About Section -->


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg ">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>Our Features</h2>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="100">
                        <i class="icofont-computer"></i>
                        <h4><a href="#">Smart Map</a></h4>
                        <p>One of the platform's greatest achievements is the work of the smart map and it is considered the first in its field and pioneering to enable the user to connect to the
                            right resource with one minute in more than 500 available categories.</p>
                    </div>
                </div>

                <div class="col-md-6 mt-4 mt-md-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="500">
                        <i class="icofont-earth"></i>
                        <h4><a href="#">Saving time and effort</a></h4>
                        <p>
                            1- It is the primary measure on which the platform is built.<br>
                            2- Fast and easy electronic accreditation.<br>
                            3- Quickly obtaining quotations from several suppliers.<br>
                            4- Quick and easy access to the right resource.<br>

                        </p>
                    </div>
                </div>
                <div class="col-md-6 mt-4 mt-md-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="200">
                        <i class="icofont-chart-bar-graph"></i>
                        <h4><a href="#">Safety</a></h4>
                        <p>All operations are saved in a reference cloud and are never removed<br>The latest security technologies are used to ensure that the user account is not tampered with</p>
                    </div>
                </div>

                <div class="col-md-6 mt-4 mt-md-0">
                    <div class="icon-box" data-aos="fade-up" data-aos-delay="400">
                        <i class="icofont-settings"></i>
                        <h4><a href="#">Quality</a></h4>
                        <p>One of the basic of our work in the platform is to ensure the quality of users' operations.</p><br>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- End Services Section -->


    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>Frequently Asked Questions</h2>
            </div>

            <ul class="faq-list accordion" data-aos="fade-up">
                @foreach(\App\Models\FAQs::all() as $faq)
                <li>
                    <a data-bs-toggle="collapse" class="collapsed" data-bs-target="#faq{{$faq->id}}">{{$faq->question_en}}<i class="bx bx-chevron-down icon-show"></i><i
                            class="bx bx-x icon-close"></i></a>
                    <div id="faq{{$faq->id}}" class="collapse" data-bs-parent=".faq-list">
                        <p>
                            {{$faq->answer_en}}
                        </p>
                    </div>
                </li>
                @endforeach
            </ul>

        </div>
    </section><!-- End Frequently Asked Questions Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team">
        <div class="container" data-aos="fade-up">

            <div class="section-title">
                <h2>Meet the Team</h2>
            </div>

            <div class="row">
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member" data-aos="fade-up" data-aos-delay="100">
                        <div class="member-img">
                            <img src="{{url('webmainimages/male.jpeg')}}" class="img-fluid" alt="">
                            <div class="social">
                                <a href=""><i class="icofont-twitter"></i></a>
                                <a href=""><i class="icofont-facebook"></i></a>
                                <a href=""><i class="icofont-instagram"></i></a>
                                <a href=""><i class="icofont-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4>Abdulaziz AlSinany</h4>
                            <span>Founder and CEO</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member" data-aos="fade-up" data-aos-delay="400">
                        <div class="member-img">
                            <img src="{{url('webmainimages/male.jpeg')}}" class="img-fluid" alt="">
                            <div class="social">
                                <a href=""><i class="icofont-twitter"></i></a>
                                <a href=""><i class="icofont-facebook"></i></a>
                                <a href=""><i class="icofont-instagram"></i></a>
                                <a href=""><i class="icofont-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4>Ahsan Raza </h4>
                            <span>Business Development Manager </span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member" data-aos="fade-up" data-aos-delay="200">
                        <div class="member-img">
                            <img src="{{url('webmainimages/male.jpeg')}}" class="img-fluid" alt="">
                            <div class="social">
                                <a href=""><i class="icofont-twitter"></i></a>
                                <a href=""><i class="icofont-facebook"></i></a>
                                <a href=""><i class="icofont-instagram"></i></a>
                                <a href=""><i class="icofont-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4>Rayan Al Sinany </h4>
                            <span>Juniour Accountant</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex align-items-stretch">
                    <div class="member" data-aos="fade-up" data-aos-delay="300">
                        <div class="member-img">
                            <img src="{{url('webmainimages/male.jpeg')}}" class="img-fluid" alt="">
                            <div class="social">
                                <a href=""><i class="icofont-twitter"></i></a>
                                <a href=""><i class="icofont-facebook"></i></a>
                                <a href=""><i class="icofont-instagram"></i></a>
                                <a href=""><i class="icofont-linkedin"></i></a>
                            </div>
                        </div>
                        <div class="member-info">
                            <h4>Muteb Al Buraikan</h4>
                            <span>Human Resources Specialist</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5"></div>
                <div class="col-lg-2"><a href="{{route('ourTeam')}}" class="get-started-btn">Our Team</a></div>
                <div class="col-lg-5"></div>
            </div>

        </div>
    </section>
    <!-- End Team Section -->

</main><!-- End #main -->

<!-- ======= Footer ======= -->
@include('webLayout.footer')
<!-- End Footer -->

<a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

<!-- Vendor JS Files -->
<script src="Presento/assets/vendor/jquery/jquery.min.js"></script>
<script src="Presento/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="Presento/assets/vendor/jquery.easing/jquery.easing.min.js"></script>
<script src="Presento/assets/vendor/php-email-form/validate.js"></script>
<script src="Presento/assets/vendor/owl.carousel/owl.carousel.min.js"></script>
<script src="Presento/assets/vendor/waypoints/jquery.waypoints.min.js"></script>
<script src="Presento/assets/vendor/counterup/counterup.min.js"></script>
<script src="Presento/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="Presento/assets/vendor/venobox/venobox.min.js"></script>
<script src="Presento/assets/vendor/aos/aos.js"></script>

<!-- Template Main JS File -->
<script src="Presento/assets/js/main.js"></script>

</body>

</html>
