@component('mail::message')
# Congratulations

You have successfully placed your Request For Quotation (RFQ).

Thanks,<br>
{{ config('app.name') }}
@endcomponent
