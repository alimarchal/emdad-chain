@component('mail::DeliveryCompleted', ['deliveries' => $deliveries])
    # Hi!

    DN-{{$deliveryID}} has been delivery.
@endcomponent
