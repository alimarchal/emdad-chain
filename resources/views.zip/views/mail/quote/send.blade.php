@component('mail::message')
# Quote Send

You have successfully sent a quotation. Please login to view your quote.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
