@component('mail::message')
# Unfortunatly

Your business registration is not approved. Please contact Customer Support.


Thanks,<br>
{{ config('app.name') }}
@endcomponent
