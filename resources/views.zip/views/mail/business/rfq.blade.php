@component('mail::message')
# Introduction

New business RFQ has been created.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
