body {
direction: rtl;
text-align: right;
}
