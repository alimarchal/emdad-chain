<div class="col-md-9 col-sm-12 col-12 col-lg-9">
    <ul class="d-flex account_login-area ul_content">
        <li class="account-item" style="transform: scaleX(-1);">
            <i class="fa fa-phone" aria-hidden="true"></i>
            <h5 style="transform: scaleX(-1);"><span>الهاتف</span>+9200 12057</h5>
        </li>
        <li class="account-item account-item-2" style="transform: scaleX(-1);">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
            <h5 style="transform: scaleX(-1);"><span>البريد الإلكتروني</span>info@emdad-chain.com</h5>
        </li>
        <li class="account-item company" style="direction: rtl; width: 335px;">
            <i class="fa fa-map-marker" aria-hidden="true"></i>
            <h5 class="company"><span>العنوان</span>مركز ابان ١٢٠،<br>طريق الملك عبد العزيز، مخرج ٥ <br>المملكة العربية السعودية، الرياض - ١٣٥٢٥</h5>
        </li>
    </ul>
</div>

<div class="col-lg-3 col-md-3 col-sm-12 col-12">
    <div class="logo" style="margin-top: 0px;">
        <a href="{{route('arabic.index')}}"><img src="{{url('Shipter/assets/images/colord Logo-01.png')}}" alt="" style="max-height: 90px"></a>
    </div>
</div>
