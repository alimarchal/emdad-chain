@include('shipterAr.header')
@yield('inside-body')
@include('shipterAr.footer')
