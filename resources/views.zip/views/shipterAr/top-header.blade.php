<div class="col-md-6 col-sm-12 col-12 col-lg-6">
    <ul class="d-flex account_login-area">
        <li>
            باستطاعتك الآن التسجيل في منصة إمداد مجانا ً

            <a href="{{route('english.index')}}" class="btn btn-warning"><img alt="" src="{{url('us.png')}}" style="font-family: 'Raleway', sans-serif;margin-right: 2px;margin-top: 4px;">&nbsp;English</a>
        </li>


    </ul>
</div>
<div class="col-md-6 col-sm-12 col-12 col-lg-6">
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <ul class="login-r">
                <li><a style="color: white;" href="{{route('login')}}">
                        الدخول الى المنصة
                    </a> </li>
            </ul>
        </div>
        <div class="col-lg-6 col-md-6">
            <li><img src="{{url('Shipter/assets/images/logo/logo-2030.png')}}" alt="Vision 2030" style="height: 30px; width: 50px;"></li>
        </div>
    </div>
</div>
