@include('shipter.header')
@yield('inside-body')
@include('shipter.footer')
