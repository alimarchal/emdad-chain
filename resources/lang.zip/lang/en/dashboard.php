<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Dashboard English Language Words
    |--------------------------------------------------------------------------
    |
    */

    'Dashboard' => 'Dashboard',
    'Total RFQs' => 'Total Requisitions',
    'Total Quotation(s)' => 'Total Quotation(s)',
    'Total Purchase Order(s)' => 'Total Purchase Order(s)',
    'Total Shipments Delivered' => 'Total Shipments Delivered',
    'Total User' => 'Total User',
    'Total Business' => 'Total Business',
    'Received RFQ' => 'Received Requisition(s)',
];
