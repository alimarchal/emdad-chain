<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Login View Arabic Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'Email' => 'Email',
    'Password' => 'Password',
    'Register' => 'Register',
    'Remember me' => 'Remember me',
    'Forgot your password?' => 'Forgot your password?',
    'Login' => 'Login',
    'Not a member?' => 'Not a member?',

];
