<?php

return [

    /*
    |--------------------------------------------------------------------------
    | navigation-dropdown English Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'Days remaining' => 'الأيام المتبقية:',
    'Remaining Businesses' => 'العمليات المتبقية:',
    'Policy and Procedure' => 'الشروط والأحكام',
    'Dashboard' => 'لوحة القيادة',
    'Manage Account' => 'إدارة الحساب',
    'Change Password' => 'تغيير كلمة المرور',
    'Profile' => 'الملف الشخصي',
    'Logout' => 'تسجيل خروج',
];
