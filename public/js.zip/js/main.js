import 'alpinejs';

// console.log(location.href.substring(location.href.lastIndexOf('/') + 1));
