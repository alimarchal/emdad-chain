<?php

namespace App\Http\Livewire;

use Livewire\Component;

class BusinessWarehouse extends Component
{
    public function render()
    {
        return view('livewire.business-warehouse');
    }
}
