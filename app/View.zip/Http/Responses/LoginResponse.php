<?php
//namespace App\Http\Responses;
//use Laravel\Fortify\Contracts\LoginResponse as ContractsLoginResponse;
//class LoginResponse implements ContractsLoginResponse
//{
//    public function toResponse($request)
//    {
//        if (auth()->user()->logistic_solution == 1) {
//            return dd('ss');
//        } else {
//            return redirect()->intended(config('fortify.home'));
//        }
//
//    }
//}
