<div class="col-md-6 col-sm-12 col-12 col-lg-6">
    <ul class="d-flex account_login-area">
        <li>You can register now with Emdad for free</li>
    </ul>
</div>
<div class="col-md-6 col-sm-12 col-12 col-lg-6">
    <div class="row">
{{--        <div class="col-lg-9 col-md-6">--}}
{{--        </div>--}}
        <div class="col-lg-9 col-md-6">
            <ul class="login-r">
                <li><a style="color: white" href="{{route('login')}}">Login</a></li>
{{--                <li><a href="{{route('register')}}">Register</a></li>--}}
            </ul>
        </div>

        <div class="col-lg-3 col-md-6">
                <li><img src="{{url('Shipter/assets/images/logo/logo-2030.png')}}" alt="Vision 2030" style="height: 30px; width: 50px;"></li>
        </div>
    </div>
</div>
