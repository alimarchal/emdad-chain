<div class="col-md-8 col-sm-12 col-12 col-lg-8">
    <ul class="d-flex account_login-area">
        <li>باستطاعتك الآن التسجيل في منصة إمداد مجاناً</li>
    </ul>
</div>
<div class="col-md-3 col-sm-12 col-12 col-lg-3">
    <div class="row">
        <div class="col-lg-6 col-md-6">
            <ul class="login-r">
                <li><a style="color: white;" href="{{route('login')}}">دخول</a></li>
            </ul>
        </div>

        <div class="col-lg-6 col-md-6">
            <li><img src="{{url('Shipter/assets/images/logo/logo-2030.png')}}" alt="Vision 2030" style="height: 30px; width: 50px;"></li>
        </div>
    </div>
</div>
