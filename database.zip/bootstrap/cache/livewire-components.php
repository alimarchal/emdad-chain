<?php return array (
  'business-warehouse' => 'App\\Http\\Livewire\\BusinessWarehouse',
  'purchase-request-form' => 'App\\Http\\Livewire\\PurchaseRequestForm',
  'registration-type' => 'App\\Http\\Livewire\\RegistrationType',
);