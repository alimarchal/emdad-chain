<?php

namespace Database\Factories;

use App\Models\BusinessWarehouse;
use Illuminate\Database\Eloquent\Factories\Factory;

class BusinessWarehouseFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = BusinessWarehouse::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
