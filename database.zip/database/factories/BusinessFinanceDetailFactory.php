<?php

namespace Database\Factories;

use App\Models\BusinessFinanceDetail;
use Illuminate\Database\Eloquent\Factories\Factory;

class BusinessFinanceDetailFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = BusinessFinanceDetail::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
