require('./bootstrap');

require('alpinejs');

import 'alpinejs';
