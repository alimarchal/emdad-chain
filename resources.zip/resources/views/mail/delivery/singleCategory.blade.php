@component('mail::singleCategoryDeliveryCompleted', ['deliveries' => $deliveries])
    # Hi!

    DN-{{$deliveryID}} has been delivery.
@endcomponent
