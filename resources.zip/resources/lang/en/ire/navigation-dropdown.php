<?php

return [

    /*
    |--------------------------------------------------------------------------
    | navigation-dropdown English Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'Days remaining' => 'Days remaining:',
    'Remaining Businesses' => 'Remaining Businesses:',
    'Policy and Procedure' => 'Policy and Procedure',
    'Dashboard' => 'Dashboard',
    'Manage Account' => 'Manage Account',
    'Change Password' => 'Change Password',
    'Profile' => 'Profile',
    'Logout' => 'Logout',
];
