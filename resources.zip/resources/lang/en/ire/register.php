<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Register View Arabic Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'Select' => 'Select',
    'Mr.' => 'Mr.',
    'Ms.' => 'Ms.',
    'Mrs.' => 'Mrs.',
    'First Name' => 'First Name',
    'Last Name' => 'Last Name',
    'Mobile Number' => 'Mobile Number',
    'Email' => 'Email',
    'Password' => 'Password',
    'Confirm Password' => 'Confirm Password',
    'I agree' => 'I agree',
    'Policy and Procedures' => 'Policy and Procedures',
    'Already registered?' => 'Already registered?',
    'Register' => 'Register',

];
