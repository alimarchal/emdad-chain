<?php return array (
  'business-warehouse' => 'App\\Http\\Livewire\\BusinessWarehouse',
  'country' => 'App\\Http\\Livewire\\Country',
  'purchase-request-form' => 'App\\Http\\Livewire\\PurchaseRequestForm',
  'registration-type' => 'App\\Http\\Livewire\\RegistrationType',
);